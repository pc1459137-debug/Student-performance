# Student Performance Prediction Using Machine Learning

## 1. Abstract
This project presents a machine learning system for predicting a student's final academic score using educational and lifestyle-related features. The system follows a complete machine learning workflow: dataset preparation, exploratory analysis, train-test splitting, model training, evaluation, and prediction. A Random Forest Regression model is used because it can learn nonlinear relationships between multiple input features and the target score. A Streamlit interface allows a user to enter student details and obtain an estimated final score and performance level.

## 2. Introduction
Machine learning enables computer systems to learn patterns from data and make predictions. In education, predictive models can be used as academic support tools to identify patterns associated with student performance. This project demonstrates the fundamentals of supervised learning using a regression problem.

## 3. Problem Statement
Manual estimation of student performance may not consider multiple factors together. The project aims to build a simple machine learning model that estimates final academic score from measurable student features.

## 4. Objectives
- Prepare a structured student dataset.
- Perform basic exploratory data analysis.
- Train a supervised machine learning regression model.
- Evaluate the model using MAE, RMSE and R².
- Provide a simple prediction interface.
- Demonstrate the complete foundation of a machine learning workflow.

## 5. Dataset
The included dataset is synthetic and contains 500 records. Features:
- Age
- Study_Hours
- Attendance
- Previous_Marks
- Assignment_Score
- Sleep_Hours
- Internet_Access

Target:
- Final_Score

The synthetic dataset is created for academic demonstration and is not intended to represent real students.

## 6. Technologies Used
- Python
- Pandas
- NumPy
- Scikit-learn
- Matplotlib
- Seaborn
- Streamlit
- Joblib
- Kiro IDE

## 7. Methodology
### Step 1: Data Preparation
The dataset is loaded with Pandas and separated into input features and the target variable.

### Step 2: Train-Test Split
80% of the records are used for training and 20% for testing.

### Step 3: Model Selection
RandomForestRegressor is selected for supervised regression.

### Step 4: Training
The model learns relationships between student features and final score.

### Step 5: Evaluation
The model is evaluated using:
- Mean Absolute Error (MAE)
- Root Mean Squared Error (RMSE)
- R² Score

### Step 6: Deployment
The trained model is loaded into a Streamlit web application for interactive predictions.

## 8. System Requirements
### Hardware
- 4 GB RAM or more recommended
- Dual-core processor or better
- 500 MB free storage

### Software
- Python 3.10 or newer recommended
- Kiro IDE
- Internet is only needed to install Python packages; the application itself does not require an API key.

## 9. Advantages
- Simple and easy to understand.
- Demonstrates supervised learning.
- Interactive user interface.
- No external API credentials required.
- Easy to run locally.

## 10. Limitations
- The dataset is synthetic.
- Predictions are for academic demonstration only.
- The model cannot capture all real-world factors affecting academic performance.
- It should not be used for high-stakes educational decisions.

## 11. Future Scope
- Use a larger real-world educational dataset with appropriate permissions.
- Compare Linear Regression, Decision Tree, Random Forest and Gradient Boosting.
- Add model comparison charts.
- Add cross-validation and hyperparameter tuning.
- Deploy the application to a cloud platform.
- Add explainable AI techniques such as feature importance and SHAP.

## 12. Conclusion
The Student Performance Prediction project demonstrates the fundamental stages of a machine learning project from data preparation to deployment. The Random Forest regression model provides a practical way to learn relationships between student-related features and predicted final scores. The Streamlit interface makes the model easy to demonstrate and use.

## 13. Viva Summary
The project is a supervised machine learning regression application. The input consists of student features and the output is the predicted final score. Random Forest Regression is used, and performance is evaluated using MAE, RMSE and R².
