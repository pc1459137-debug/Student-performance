# Student Performance Prediction Using Machine Learning

Foundation of Machine Learning project built with Python, Scikit-learn and Streamlit.

## Features
- Student score prediction
- Random Forest Regression
- Dataset exploration
- Correlation heatmap
- Score distribution
- Simple Streamlit UI
- No API key required
- Runs locally in Kiro

## Kiro / Windows Setup

Open this folder in Kiro and run:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python train_model.py
streamlit run app.py
```

If PowerShell blocks activation, run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

Then open the Streamlit URL shown in the terminal, usually:
`http://localhost:8501`

## Files
- `app.py` - Streamlit application
- `train_model.py` - model training and evaluation
- `data/student_data.csv` - synthetic dataset
- `models/` - trained model is created here
- `report/PROJECT_REPORT.md` - project report
- `requirements.txt` - dependencies
