import os
import joblib
import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns

st.set_page_config(
    page_title="Student Performance Predictor",
    page_icon="🎓",
    layout="wide"
)

MODEL_PATH = "models/student_performance_model.pkl"
DATA_PATH = "data/student_data.csv"

@st.cache_resource
def load_model():
    if not os.path.exists(MODEL_PATH):
        return None
    return joblib.load(MODEL_PATH)

@st.cache_data
def load_data():
    return pd.read_csv(DATA_PATH)

def performance_label(score):
    if score >= 85:
        return "Excellent"
    if score >= 70:
        return "Good"
    if score >= 50:
        return "Average"
    return "Needs Improvement"

st.title("🎓 Student Performance Prediction")
st.caption("Foundation of Machine Learning Project")

model = load_model()
data = load_data()

if model is None:
    st.warning("Model not found. Run `python train_model.py` first.")
    st.stop()

tab1, tab2, tab3 = st.tabs(["🔮 Prediction", "📊 Dataset & Analysis", "ℹ️ About"])

with tab1:
    st.subheader("Enter Student Details")
    c1, c2 = st.columns(2)
    with c1:
        age = st.slider("Age", 15, 21, 18)
        study = st.slider("Study Hours / Day", 0.5, 10.0, 4.5, 0.5)
        attendance = st.slider("Attendance (%)", 40.0, 100.0, 80.0, 1.0)
        previous = st.slider("Previous Marks (%)", 20.0, 100.0, 70.0, 1.0)
    with c2:
        assignments = st.slider("Assignment Score (%)", 20.0, 100.0, 75.0, 1.0)
        sleep = st.slider("Sleep Hours / Day", 4.0, 10.0, 7.0, 0.5)
        internet = st.selectbox("Internet Access", ["Yes", "No"])

    if st.button("Predict Final Score", type="primary"):
        row = pd.DataFrame([{
            "Age": age,
            "Study_Hours": study,
            "Attendance": attendance,
            "Previous_Marks": previous,
            "Assignment_Score": assignments,
            "Sleep_Hours": sleep,
            "Internet_Access": 1 if internet == "Yes" else 0
        }])
        prediction = float(model.predict(row)[0])
        prediction = float(np.clip(prediction, 0, 100))
        label = performance_label(prediction)

        m1, m2 = st.columns(2)
        m1.metric("Predicted Final Score", f"{prediction:.2f}%")
        m2.metric("Performance Level", label)

        st.progress(int(round(prediction)))
        if prediction >= 70:
            st.success("The predicted performance is positive. Continue consistent study and attendance.")
        elif prediction >= 50:
            st.info("The prediction is moderate. Improving study time and attendance may help.")
        else:
            st.warning("The prediction suggests improvement is needed. Focus on regular study and assignments.")

with tab2:
    st.subheader("Dataset Preview")
    st.dataframe(data.head(20), use_container_width=True)

    col1, col2 = st.columns(2)
    with col1:
        fig, ax = plt.subplots()
        sns.histplot(data["Final_Score"], kde=True, ax=ax)
        ax.set_title("Distribution of Final Scores")
        st.pyplot(fig)
        plt.close(fig)

    with col2:
        fig, ax = plt.subplots()
        corr = data.corr(numeric_only=True)
        sns.heatmap(corr, annot=True, fmt=".2f", ax=ax)
        ax.set_title("Feature Correlation")
        st.pyplot(fig)
        plt.close(fig)

    st.write("Dataset shape:", data.shape)

with tab3:
    st.markdown("""
    ### Project Objective
    Predict a student's final academic score from educational and lifestyle features.

    ### Machine Learning Workflow
    1. Dataset creation
    2. Data preprocessing
    3. Feature/target separation
    4. Train-test split
    5. Random Forest Regression
    6. Model evaluation
    7. Prediction through Streamlit

    ### Important Note
    The included dataset is synthetic and intended for academic demonstration.
    It should not be used for real admissions, grading, or high-stakes decisions.
    """)
