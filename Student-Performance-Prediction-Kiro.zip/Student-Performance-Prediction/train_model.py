import os
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

DATA_PATH = "data/student_data.csv"
MODEL_PATH = "models/student_performance_model.pkl"

df = pd.read_csv(DATA_PATH)
X = df.drop(columns=["Final_Score"])
y = df["Final_Score"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42
)

model = RandomForestRegressor(
    n_estimators=200, random_state=42, max_depth=10
)
model.fit(X_train, y_train)

pred = model.predict(X_test)
mae = mean_absolute_error(y_test, pred)
rmse = mean_squared_error(y_test, pred) ** 0.5
r2 = r2_score(y_test, pred)

os.makedirs("models", exist_ok=True)
joblib.dump(model, MODEL_PATH)

print("Model trained successfully.")
print(f"MAE : {mae:.2f}")
print(f"RMSE: {rmse:.2f}")
print(f"R2  : {r2:.3f}")
print(f"Saved to: {MODEL_PATH}")
